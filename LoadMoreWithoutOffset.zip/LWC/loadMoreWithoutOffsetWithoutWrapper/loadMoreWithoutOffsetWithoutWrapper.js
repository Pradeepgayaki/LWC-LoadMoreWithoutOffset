import { LightningElement, track, wire } from 'lwc';
import { CurrentPageReference,NavigationMixin } from 'lightning/navigation'; 
import getOpportunityDetailsWithoutWrapper from '@salesforce/apex/LoadMoreWithoutOffset.getOpportunityDetailsWithoutWrapper';

export default class LoadMoreWithoutOffsetWithoutWrapper extends NavigationMixin(LightningElement) {
    @track accountId;
    @track dataOpportunity=[];

    @wire(CurrentPageReference) currentPageReference;
    
    showOpportunity;
    accId;
    lastRecordId;
    lastRecordValue;
    
    @track columns = [
        {
            label: 'Opportunity Name',
            fieldName: 'Id',
            type: 'button',
            typeAttributes: {
                label:{fieldName: 'Name' },
                name:'View'
            }
        },
        {
            label: 'Close date',
            fieldName: 'CloseDate',
            type: 'text',
            cellAttributes: { alignment: 'left' }
        },
        {
            label: 'Stage Name',
            fieldName: 'StageName',
            type: 'text',
            cellAttributes: { alignment: 'left' }
        }
    ];

    handleLoadMore()
    {
        this.opportunityDetails();
    }
    
    handleRowAction( event ) {  
        const recId =  event.detail.row.Id;  
        const actionName = event.detail.action.name;  
        if ( actionName === 'View') {  
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                  recordId: recId,
                  objectApiName: 'Opportunity',
                  actionName: 'view'
                }
              });
        }          
    }
    opportunityDetails(){
        this.accId='0015g00000BnWYuAAN';
        if(this.accId){
            /*String accountId, 
String sortByField, String sortOrder, Id lastRecordId, 
Date lastSortedFieldValue, Boolean isSortedInteger*/
            getOpportunityDetailsWithoutWrapper({ accountId: this.accId, 
                sortByField: 'CloseDate', sortOrder: 'desc', lastRecordId: this.lastRecordId,
                lastSortedFieldValue: this.lastRecordValue, isSortedInteger: false})
            .then(result => {
                console.log('result without wrapper:', JSON.stringify(result));
                console.log('result.length 1 :', result.length);
                if(result.length>0){
                    if(this.lastRecordId!=result[result.length-1].Id)
                    {                

                        this.dataOpportunity=[...this.dataOpportunity,...result];
                        console.log('this.dataOpportunity withouut wrapper=:', this.dataOpportunity);
                        this.lastRecordId=this.dataOpportunity[this.dataOpportunity.length-1].Id;
                        this.lastRecordValue = this.dataOpportunity[this.dataOpportunity.length-1].CloseDate;
                    }
                }
                this.showOpportunity=true;
            }
            )
            .catch(error => {
                console.log('error opportunityDetails:', error);
                this.showOpportunity=false;
            });
        }
    }
    connectedCallback()
    {
 //       this.accId='0015g00000BnWYuAAN';
        this.opportunityDetails();
    }
}