import { LightningElement, track, wire } from 'lwc';
import { CurrentPageReference,NavigationMixin } from 'lightning/navigation'; 
import getOpportunityDetails from '@salesforce/apex/LoadMoreWithoutOffset.getOpportunityDetails';

export default class LoadMoreWithoutOffset extends NavigationMixin(LightningElement) {
    @track accountId;
    @track dataOpportunity=[];

    @wire(CurrentPageReference) currentPageReference;
    
    showOpportunity;
    accId;
    lastRecordId;
    lastRecordValue;

    @track columns = [
        {
            label: 'Opportunity Name',
            fieldName: 'recordId',
            type: 'button',
            typeAttributes: {
                label:{fieldName: 'opportunityName' },
                name:'View'
            }
        },
        {
            label: 'Account Name',
            fieldName: 'accountName',
            type: 'text'
        },
        {
            label: 'Close date',
            fieldName: 'closeDate',
            type: 'text',
            cellAttributes: { alignment: 'left' }
        },
        {
            label: 'Stage Name',
            fieldName: 'stageName',
            type: 'text',
            cellAttributes: { alignment: 'left' }
        }
    ];

    handleLoadMore()
    {
        this.opportunityDetails();
    }
    
    handleRowAction( event ) {  
        const recId =  event.detail.row.Id;  
        const actionName = event.detail.action.name;  
        if ( actionName === 'View') {  
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                  recordId: recId,
                  objectApiName: 'Opportunity',
                  actionName: 'view'
                }
              });
        }          
    }
    opportunityDetails(){
        this.accId='0015g00000BnWYuAAN';
        if(this.accId){
            getOpportunityDetails({ accountId: this.accId, 
                sortByField: 'CloseDate', sortOrder: 'desc', lastRecordId: this.lastRecordId,
                lastSortedFieldValue: this.lastRecordValue, isSortedInteger: false})
            .then(result => {
                console.log('result:', JSON.stringify(result));
                console.log('result0:', result[0][0]);
                console.log('result[0].length:', result[0].length);
                if(result[0].length>0){
                    if(this.lastRecordId!=result[0][result[0].length-1].recordId)
                    {                
                        this.dataOpportunity=[...this.dataOpportunity,...result[0]];
                        console.log('this.dataOpportunity=:', this.dataOpportunity);
                        this.lastRecordId=this.dataOpportunity[this.dataOpportunity.length-1].recordId;
                        this.lastRecordValue = this.dataOpportunity[this.dataOpportunity.length-1].closeDate;
                    }
                }
                this.showOpportunity=true;
            }
            )
            .catch(error => {
                console.log('error opportunityDetails:', error);
                this.showOpportunity=false;
            });
        }
    }
    connectedCallback()
    {
        this.opportunityDetails();
    }
}